//-*-c++-*-
#ifndef INCLUDED_SocketListener_h_
#define INCLUDED_SocketListener_h_

#include "Wireless/Wireless.h"
#include "AMORAIController.h"
#include "SocketBase.h"

class SocketListener;
int socketListenerReader(char*,int);


template <class T>
class AMORAIController;

extern std::map<std::string, unsigned int> AMORAI::portMap;

class SocketListener : public SocketBase {
private:
  unsigned int bufferSize;
  unsigned int bufferPos;
  bool bufferFixed;
  unsigned int comPort;
  Socket *comSocket; 


  //Warning Supression
  SocketListener(const SocketListener&);
  SocketListener operator=(const SocketListener&);

  static std::map<unsigned int, SocketListener*> listeners;
  
  
protected:
  char *buffer;

public:

  static void registerListener(unsigned int port, SocketListener* listener)
    {
      listeners[port] = listener;
    }

  static void dropListener(unsigned int port)
    {
      listeners.erase(port);
    }
  
  static int readInt(char* &buf, int &bytes) {
    int toReturn = 0;
    for(unsigned int i = 0; i < 4; i++  )
      {
	((char*)(&toReturn))[i] = buf[i];
      }
    // ((int*)buf)[0] would work huh?
    buf = buf + 4;
    bytes = bytes - 4;
    return toReturn; 
  }

  static SocketListener* getListener(unsigned int port)
    {
      //Error checking forgone for effeciency
      std::map<unsigned int, SocketListener*>::iterator iter = listeners.find(port);
      if( iter != listeners.end() ) {
	return (*iter).second;
	}
      else {	
	return NULL;
      }
    }
      

  SocketListener(std::string classname, bool fixed, unsigned int bytes) :
    SocketBase(classname),
    bufferSize(bytes),
    bufferFixed(fixed),
    comPort((AMORAI::portMap[classname])),
    comSocket(NULL),
    bufferPos(0),
    buffer(NULL)
    {
      serr->printf("listener port for %s is %d\n", classname.c_str(), comPort);
      buffer = (char *) calloc( sizeof(char), bufferSize);
      SocketListener::registerListener(comPort, this);
    }
  

  virtual void DoStart()
    {
      SocketBase::DoStart();
      comSocket = wireless->socket(SocketNS::SOCK_STREAM, 2048, 1024);
      wireless->setReceiver(comSocket->sock, socketListenerReader );
      wireless->setDaemon(comSocket, true);
      wireless->listen(comSocket->sock, comPort);
    }


  int registerData(char* buf, int bytes)
    {
      unsigned int read = 0;
      unsigned int size = 0;
      if( !bufferFixed )
	{
	  size = readInt(buf, bytes); 
	}
      while( read < bytes )
	{
	  buffer[bufferPos++] = buf[ read++ ];
	  if(bufferPos == bufferSize && bufferFixed)
	    {
	      processData();
	      bufferPos = 0;
	    }
	  else if( bufferPos == size && !bufferFixed)
	    {
	      processData(size);
	      bufferPos = 0;
	    }
	}
      return read;
    } 

  virtual void DoStop()
    {
      wireless->setDaemon(comSocket, false);
      wireless->close(comSocket);
      SocketBase::DoStop();
    }
  
  virtual void processData() {} 
  virtual void processData(int size) {}
  ~SocketListener() 
    {
      free(buffer);
    }

};

std::map<unsigned int, SocketListener*> SocketListener::listeners = std::map<unsigned int, SocketListener*>();

int socketListenerReader(char *buf, int bytes)
{
  int listenerID = SocketListener::readInt(buf, bytes);
  SocketListener* listener;

  //Socket now integer id of reader
  listener = SocketListener::getListener(listenerID);
  
  // Dispatch on listenerID
  if(listener!=NULL) {
      return listener->registerData(buf, bytes);
    }
  else {
    return 0;
  }
}

#endif
