#ifndef INCLUDED_SocketBase_h
#define INCLUDED_SocketBase_h

#include "Behaviors/BehaviorBase.h"

class SocketBase : public BehaviorBase {
 public:
  SocketBase();

  SocketBase(std::string classname)
    : BehaviorBase( classname )
    {}

  virtual void DoStart() {
    BehaviorBase::DoStart();
  }

  virtual void DoStop() {
    BehaviorBase::DoStop();
  }
};

#endif
