#include "AMORAIConfig.h"
#include <map>
#include <string>

std::map<std::string, std::string> *AMORAIConfig::config = NULL;

