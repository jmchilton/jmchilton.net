//-*-c++-*-
#ifndef INCLUDED_SoundListener_h_
#define INCLUDED_SoundListener_h_

#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "Shared/SharedObject.h"
#include "SoundPlay/SoundManager.h"
     
#define MAX_FILE_SIZE 128

//Plays sounds, based on code from SoundTestBehavior


class SoundListener : public SocketListener {
 protected:
  //Empty
 public:
  SoundListener() :
    SocketListener("SoundListener", false, sizeof(int)+MAX_FILE_SIZE*sizeof(char)),
    curplay(SoundManager::invalid_Play_ID)
  {
  serr->printf("In constructor for Sound Listener...\n\n");
  }

  virtual void processData(int size) { //Called when buffer fills    
    int num;
    char *myBuffer = buffer;
    char filename[MAX_FILE_SIZE];
    for(unsigned int i = 0; i < size; i++)
      {
	filename[i] = myBuffer[i];
      }
    filename[size] = '\0';
    serr->printf("Playing sound file: %s\n", filename);
    playSoundFile(filename);
  }
  
  virtual void DoStart() {
    serr->printf("In SoundListener's DoStart()");
    SocketListener::DoStart();
  }
  
  virtual void DoStop() {
    SocketListener::DoStop();
  }

  void playSoundFile(const char* name) {
    sndman->PlayFile(name);
  }
  
  SoundManager::Play_ID curplay;

 private: //For Error Suppression
  SoundListener(const SoundListener&);
  SoundListener operator=(const SoundListener&);
  
};

#endif
