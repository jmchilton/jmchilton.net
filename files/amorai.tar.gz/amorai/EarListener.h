//-*-c++-*-
#ifndef INCLUDED_EarListener_h_
#define INCLUDED_EarListener_h_
 
#include "Motion/MotionManager.h"
#include "Motion/PostureMC.h"
#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "Shared/SharedObject.h"

class EarListener : public SocketListener {
protected:
  MotionManager::MC_ID poseID;
  PostureMC* pose;
  float* earVals; 
  
public:
  EarListener() :
    SocketListener("EarListener", true, 2*sizeof(float)),
    earVals((float*)buffer),
    poseID(MotionManager::invalid_MC_ID),
    pose(NULL)
  {}
  
  virtual void processData() { //Called when buffer fills    
    pose->setOutputCmd(ERS7Info::EarOffset   , earVals[0]);
    pose->setOutputCmd(ERS7Info::EarOffset+1 , earVals[1]);
  }
  
  virtual void DoStart() {
    poseID=motman->addPersistentMotion(SharedObject<PostureMC>());
    pose = (PostureMC*)motman->peekMotion(poseID);
    SocketListener::DoStart();
  }
  
  virtual void DoStop() {
    motman->removeMotion(poseID);
    pose = NULL;
    SocketListener::DoStop();
  }
  
private: //For Error Suppression
  EarListener(const EarListener&);
  EarListener operator=(const EarListener&);
  
};

#endif
