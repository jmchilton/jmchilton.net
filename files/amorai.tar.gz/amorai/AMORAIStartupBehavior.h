//-*-c++-*-
#ifndef INCLUDED_AMORAIStartupBehavior_h_
#define INCLUDED_AMORAIStartupBehavior_h_

#include "AMORAIController.h"
#include "AMORAIConfig.h"

class AMORAIStartupBehavior : public BehaviorBase {
public:
  
  virtual void DoStart() {
    BehaviorBase::DoStart();
    serr->printf( "About to read config file\n");
    AMORAIConfig::readConfigFile("/ms/config/amorai.cfg");
    serr->printf( "Read config file\n" );
    initialize();
  }
  
  virtual void DoStop() {
    BehaviorBase::DoStop();
  }
  
  template <class T>
  void add(AMORAIController<T>* control, std::string str, unsigned int port=0, bool start=true) {
    if( port == 0 ) 
      control->init(str);
    else
      control->init(str, port, start);
  }



  AMORAIStartupBehavior() 
    : BehaviorBase("AMORIA Startup Behavior")
  {}

  void initialize(); // Defined in AMORAIStartupBehavior.cc, add listeners and writers there
};

#endif
