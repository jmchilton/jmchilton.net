// This file is merely to workaround a bug in:
// OPEN_R_SDK/OPEN_R/include/OPENR/core_macro.h:10
// which says  #include "entry.h" (a stub-generated file, specific to each process)

