//-*-c++-*-
#ifndef INCLUDED_AMORAIConfig_h_
#define INCLUDED_AMORAIConfig_h_

#include <map>
#include <stdio.h>
#include <sstream>
#include <string>
#include "Wireless/Wireless.h" //For serr


class AMORAIConfig {
public:
  static std::map<std::string, std::string> *config;

  static void readConfigFile(const char* filename) {
    if(config != NULL) {
      delete config;
    }
    config = new std::map<std::string, std::string>();
    //std::ifstream configStream(configFile, ios::in);
    std::string line;
    std::string key, value;
    std::istringstream *strStream;
    unsigned int pos;
    FILE* fp = fopen(filename, "r");
    char buf[80];
    while( fscanf(fp,"%79[^\n]\n" ,buf ) != EOF )
      {
	serr->printf("In read's while loop\n");
	line = buf; 
	pos = line.find_first_not_of(" ");
	if( pos == std::string::npos || line[pos] == '#' ) {
	  continue;
	}
	strStream = new std::istringstream(); 
	strStream->str(line);
	key = "";
	value = "";
	(*strStream) >> key >> value;
	//canf(buf, "%s %s", key, value);
	serr->printf("buff: %s", buf);
	serr->printf("line: %s", line.c_str());
	serr->printf("kv: %s %s\n", key.c_str(), value.c_str());
	(*config)[key] = value;
	delete strStream;
      }
    fclose(fp);
  }

  static std::string getValue(std::string &key) {
    std::map<std::string, std::string>::iterator iter = config->find(key);
    if( iter != config->end() ) {
      return iter->second;
    }
    else {
      serr->printf("getValue in AMORAIConfig called with unknow key\n");
      return "";
    }
  }

  static int getPort(std::string classStr) {
    //std::string port = AMORAIConfig::getValue(classStr+"Port");
    std::map<std::string, std::string>::iterator iter;
    iter = config->find(classStr+"Port");
    
    if( iter == config->end() ) {
      serr->printf("getPort in AMORAIConfig called with unknown classStr %s\n", classStr.c_str() );
      return 0; //Port not found
    }
    
    std::istringstream i(iter->second);
    unsigned int portNum;
    i >> portNum;
    return portNum;
  }
  
  static bool getStart(std::string classStr) {
    //std::string start = AMORAIConfig::getValue(classStr+"Start");
    std::map<std::string, std::string>::iterator iter;
    iter = config->find(classStr+"Start");
    
    if( iter == config->end() ) {
      serr->printf("getStart in AMORAIConfig called with unknown classStr\n");
      return false; //Port not found
    }
    std::istringstream i(iter->second);
    bool startBool;
    i >> startBool;
    return startBool;
  }

  template <class T>
  static bool assignValue(std::string key, T& obj) {
    std::map<std::string, std::string>::iterator iter;
    iter = config->find(key);
    if( iter == config->end() ) {
      serr->printf("AIBOConfig failed to find %s\n", key.c_str());
      return false;
    }
    std::istringstream i(iter->second);
    i >> obj;
    return true;
  }

};



#endif
