//-*-c++-*-
//Behaviors/Controls/LoadWalkControl to change walk...
#ifndef INCLUDED_WalkListener_h_
#define INCLUDED_WalkListener_h_

#include "Motion/MotionManager.h"
#include "Motion/MMAccessor.h"
#include "Motion/WalkMC.h"
#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "Shared/SharedObject.h"

class WalkListener : public SocketListener {
protected:
  SharedObject<WalkMC> shared_walker;

  
public:
  static SharedObject<WalkMC>* shared_walk;

  WalkListener():
    SocketListener("WalkListener", true, 3*sizeof(float)),
    shared_walker()
  {
    shared_walk = &shared_walker; 
  }

  virtual WalkMC* getWalkMC() {
    return &(*shared_walker);
  }

  virtual MotionManager::MC_ID getWalkID() {
    return shared_walker->getID();
  }

  virtual void processData() {

    float* amt = ((float*)buffer);
    float dx = amt[0];
    float dy = amt[1];
    float da = amt[2];

    //Following code taken directly from WalkControlllerBehavior.cc
    MMAccessor<WalkMC> walker(getWalkID());
    float tdx=dx*walker->getCP().max_vel[dx>0?WalkMC::CalibrationParam::forward:WalkMC::CalibrationParam::reverse];
    float tdy=dy*walker->getCP().max_vel[WalkMC::CalibrationParam::strafe];
    float tda=da*walker->getCP().max_vel[WalkMC::CalibrationParam::rotate];
    walker->setTargetVelocity(tdx,tdy,tda);
  }

  virtual void DoStart() {
    SocketListener::DoStart();
    motman->addPersistentMotion(shared_walker);
  }

  virtual void DoStop() {
    motman->removeMotion(getWalkID());
    SocketListener::DoStop();
  }
 
  ~WalkListener() {
    if( shared_walk == &shared_walker ) 
      shared_walk = NULL;
  }

 private: //For Error Suppression
  WalkListener(const WalkListener&);
  WalkListener operator=(const WalkListener&);
};

SharedObject<WalkMC>* WalkListener::shared_walk = NULL;

#endif
