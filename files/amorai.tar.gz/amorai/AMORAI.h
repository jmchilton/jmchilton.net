#ifndef INCLUDED_AMORAI_h_
#define INCLUDED_AMORAI_h_

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

 
typedef struct aibo_comm_struct {
  unsigned int port;
  int sockfd;
  int fixed;
} aibo_comm;
 
int aibo_read(aibo_comm *comm, char *buf, unsigned int *size) {
  int i, bytes_read, bytes_to_read;
  if(comm->fixed) {
    bytes_read = read(comm->sockfd, buf, *size, 0);
    //Convert to big endian if nessecary
    if( bytes_read < 0 ) {
      fprintf(stderr, "Failed to read from the socket\n");
      return n;
    }
    else if( bytes_read != *size ) {
      fprintf(stderr, "Socket did not contain the correct number of bytes\n");
      return 1;
    }
    return 0;
  }
  else {
    bytes_to_read = read(comm->sockfd, buf, sizeof(int), 0);
    //Convert to big endian if nessecary
    if( bytes_to_read < 0) {
      fprintf(stderr, "Error reading size in aibo_read\n");
      return n;
    }
    bytes_read = read(comm->sockfd, buf, bytes_to_read, 0);
    //Convert to big endian if nessecary
    if( n < 0 ) {
      fprintf(stderr, "Error socket contained fewer bytes then it said it would\n");
      return n;      
    } 
    *size = *bytes_read;
    return 0;
  }
}

int aibo_write(aibo_comm *comm, char *buf, int bytes) {
  char* to_send;
  int n, offset;

  if(comm->fixed) {
    to_send = (char *) malloc(sizeof(char)*bytes + sizeof(int));
    offset = sizeof(int)/sizeof(char);
  }
  else {
    to_send = (char *) malloc(sizeof(char)*bytes + 2*sizeof(int));
    offset = 2*sizeof(int)/sizeof(char);
  }

  ((int *) to_send)[0] = comm->port;
  if(comm->fixed) {
    ((int *) to_send)[1] = bytes;
  }  
  
  memcpy(to_send+offset, buf, bytes);
  n = write(comm->sockfd, to_send, bytes+offset*sizeof(char), 0);
  free(to_send);
  if(n < 0) {
    fprintf(stderr, "Error writing to socket\n");
    return -1;
  }
  return 0;
}

int aibo_comm_init(aibo_comm *comm, char* host_name, int portno, int fixed)
{
  int sockfd; 
  sockfd = get_aibo_socket_fd(host_name, portno);
  if( sockfd < 0 ) {
    fprintf(stderr, "Failed to get AIBO socket FD in aibo_comm_init\n");
    return 1;
  }
  comm = (aibo_comm *) calloc(sizeof(aibo_comm), 1);
  comm->port = portno;
  comm->sockfd = sockfd;
  comm->fixed = fixed;
  return 0;
}

int aibo_comm_destroy(aibo_comm *comm) {
  /* Needs more error checking */
  close(comm->sockfd);
  free(comm);
  return 0;
}


int get_aibo_socket_fd(char *host_name, int portno) { 
  int sockfd;
  struct sockaddr_in serv_addr;
  struct hostnet *server;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd  <  0) {
    fprintf(stderr, "Failed to create socket.\n");
    return -1;
  } 

  serv_addr.sin_family = AF_INET;
  server = gethostbyname(host_name);
  if(server == NULL) {
    fprintf(stderr, "Error: No such server found"); 
    return -2;
  }

  bcopy((char *) server->h_addr,
	(char *) &serv_addr.sin_addr.s_addr,
	server->h_length);

  serv_addr.sin_port = htons(portno);
  if(connect(sockfd, &serv_addr, sizeof(serv_addr)) < 0) {
    fprintf(stderr, "Error connecting to host.\n");
    return -3;
  }
  free(server);
  return sockfd;
}

#endif
