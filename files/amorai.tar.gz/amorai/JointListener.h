//-*-c++-*-
#ifndef INCLUDED_JointListener_h_
#define INCLUDED_JointListener_h_

#include "Motion/MotionManager.h"
#include "Motion/RemoteControllerMC.h"
#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "Shared/SharedObject.h"



class JointListener : public SocketListener {
 protected:
  MotionManager::MC_ID rcontrolID;
  float* jointVals; 
 
 public:
  JointListener() :
    SocketListener("JointListener", true, NumPIDJoints*sizeof(float)),
    jointVals((float*)buffer),
    rcontrolID(MotionManager::invalid_MC_ID)
  {}

  virtual void processData() { //Called when buffer fills    
    //Code Directly From AIBO3DController
    RemoteControllerMC *rcontrol = (RemoteControllerMC*)motman->checkoutMotion(rcontrolID);
    for (unsigned int i=0; i<NumPIDJoints; i++)
      rcontrol->cmds[i]=jointVals[i];
    rcontrol->setDirty();
    motman->checkinMotion(rcontrolID);
  }
  
  virtual void DoStart() {
    SocketListener::DoStart();
    rcontrolID = motman->addPersistentMotion(SharedObject<RemoteControllerMC>());
  }
  
  virtual void DoStop() {
    motman->removeMotion(rcontrolID);
    SocketListener::DoStop();
  }

 private: //For Error Suppression
  JointListener(const JointListener&);
  JointListener operator=(const JointListener&);
  
};

#endif
