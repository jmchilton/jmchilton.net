#include "AMORAIStartupBehavior.h"
#include "AMORAIController.h"

//Listeners and Writers
#include "LEDListener.h"
#include "WorldStateWriter.h"
#include "WalkListener.h"
#include "PostureListener.h"
#include "EarListener.h"
#include "JointListener.h"
#include "OutputListener.h"
#include "SoundListener.h"

void AMORAIStartupBehavior::initialize() {  
  // add(new AMORAIController<CLASS>(), "CLASS", port, start);
  // port is the port (int) the controller should  read from or write to
  // start should be a bool 
  //
  // add(new AMORAIController<SampleListener>("SampleListener", 13049, true));

  // Factory Listeners and Writers
  add(new AMORAIController<OutputListener>(), "OutputListener");
  add(new AMORAIController<LEDListener>(), "LEDListener");
  add(new AMORAIController<WorldStateWriter>(), "WorldStateWriter");
  add(new AMORAIController<WalkListener>(), "WalkListener");
  add(new AMORAIController<PostureListener>(), "PostureListener");
  add(new AMORAIController<EarListener>(), "EarListener");
  add(new AMORAIController<JointListener>(), "JointListener");
  add(new AMORAIController<SoundListener>(), "SoundListener");
}

