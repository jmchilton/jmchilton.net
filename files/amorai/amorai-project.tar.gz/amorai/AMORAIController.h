//-*-c++-*-
#ifndef INCLUDED_AMORAIController_h_
#define INCLUDED_AMORAIController_h_

#include <map>
#include <string>
#include "AMORAIConfig.h"
#include "SocketBase.h"
#include "Wireless/Wireless.h"

template <class T>
class AMORAIController;

namespace AMORAI {
  extern std::map<std::string, unsigned int> portMap;
}

template <class T>
class AMORAIController {
public: 
  unsigned int getPort() {
    return port;
  }
  
  std::string getClassName() {
    return className;
  }
  
  bool isActive() {
    return active;
  }
  
  bool start() {
    if( active )
      return false;
    
    object = new T();
    object->DoStart();
    active = true;
    return true;
  }

  bool stop() {
    if(!active) {
      return false;
    }
    
    object->DoStop();
    delete object;
    active = false;
    return true;
  }

  ~AMORAIController() {
    //AMORAI::AMORAIControls.erase(className);
    if( active ) {
      delete object;
    }
  }


  void init(std::string &str, unsigned int port_, bool start)
  {
    serr->printf("In AMORAIController for %s, with port %d and start: %d\n", str.c_str(), port_, (int) start);
    className = str;
    object = NULL;
    port = port_;
    active = false;
    AMORAI::portMap[className] = port;
    if(start) {
      this->start();
    }
  }

  void init(std::string &className) {
    init(className, AMORAIConfig::getPort(className), AMORAIConfig::getStart(className));
  }

protected:
  unsigned int port;
  T* object;
  bool active;
  std::string className;
};



#endif
