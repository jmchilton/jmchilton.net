//-*-c++-*-
#ifndef INCLUDED_WorldStateSerializer_h
#define INCLUDED_WorldStateSerializer_h

#include "SocketWriter.h"
#include "Shared/RobotInfo.h"
#include "Shared/WorldState.h"

//A class strongly based off of Tekkotsu Mon's WorldStateSerializer,
//but pulled into this framework

#define WORLD_STATE_BYTES 460

//
// TimeStamp      - 1 int
// NumPIDJoints   - 1 int 
// pids           - 3*NumPIDJoints(18)   - 54 ints
// joints         - NumPIDJoints ints    - 18 ints
// numSensors     - 1 int
// sensors        - 11 floats
// numButtons     - 1 int
// buttons        - NumButtons floats    - 10 floats
// utils          - NumPIDJoints floats  - 18 floats 
// 1+1+54+18+1+11+1+10+18 = 115 4 byte variables
// 4*115 = 460 bytes

#define WORLD_STATE_INTERVAL 700

//class SocketWriter;

class WorldStateWriter : public SocketWriter {

public:
  WorldStateWriter() :
    SocketWriter(std::string("WorldStateWriter"), true, WORLD_STATE_BYTES),
    lastWriteTime(0),
    WorldStateInterval(700)
  {
    AMORAIConfig::assignValue("WorldStateInterval", WorldStateInterval);
  }
  
  virtual void DoStart() {
    SocketWriter::DoStart();
    erouter->addListener(this,EventBase::sensorEGID);
  }
  
  virtual void DoStop() {
    erouter->removeListener(this);
    SocketWriter::DoStop();
  }
  
  virtual void processEvent(const EventBase& e) {
    if(( e.getTimeStamp() - lastWriteTime) < WORLD_STATE_INTERVAL) {
      return;
    }
    lastWriteTime = e.getTimeStamp();
    if( ready() ) { //Ready must preceed send call!
      fillWorldStateBuffer();
      send();
    }
  }

protected:
  
  void fillWorldStateBuffer() {
    char* localBuf = buffer;
    /*
      Writes:
      TimeStamp (1 unsigned int)
      NumPIDJoints (1 unsigned int)
      pids (3*NumPIDJoints floats)
      jointValues? (NumPIDJoints floats)
      NumSensors (1 unsigned int)
      sensor readings (NumSensors  floats)
      NumButtons (1 unsigned int)
      button values (NumButton floats)
      pidduties (NumPidJoint floats)
    */
    //Code from WorldStateSerializer

    encode(&localBuf,state->lastSensorUpdateTime);
    encode(&localBuf,NumPIDJoints);

    encode(&localBuf,(float*)(state->pids),NumPIDJoints*3);
    encode(&localBuf,(float*)(&state->outputs[PIDJointOffset]), NumPIDJoints);
    
    encode(&localBuf,NumSensors);

    encode(&localBuf,state->sensors,NumSensors);
    encode(&localBuf,NumButtons);
    encode(&localBuf,state->buttons,NumButtons);
    encode(&localBuf,state->pidduties,NumPIDJoints);
  }

  unsigned int lastWriteTime; 
  unsigned int WorldStateInterval;
  
private:
  WorldStateWriter(const WorldStateWriter&);
  WorldStateWriter& operator=(const WorldStateWriter&); 

};

#endif




