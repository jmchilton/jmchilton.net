//-*-c++-*-
#ifndef INCLUDED_LEDListener_h_
#define INCLUDED_LEDListener_h_

#include "Motion/MotionManager.h"
#include "Motion/MMAccessor.h"
#include "Motion/LedMC.h"
#include "Shared/RobotInfo.h"
#include "SocketListener.h"



class LEDListener : public SocketListener {
 protected:
  MotionManager::MC_ID ledID;
  float* ledVals; 

 public:
  LEDListener() :
    SocketListener("LEDListener", true, NumLEDs*sizeof(float)),
    ledVals((float*)buffer),
    ledID(MotionManager::invalid_MC_ID)
    {}

  virtual void processData() { //Called when buffer fills
    serr->printf("In processData of led listener.");
    MMAccessor<LedMC> ledControl(ledID); //Checkout ledControl 
    for(unsigned int i = 0; i < NumLEDs; i++ ) {
      ledControl->set( 1<<i, ledVals[i] ); 
    }
  }
  
  virtual void DoStart() {
    SocketListener::DoStart();
    ledID = motman->addPersistentMotion(SharedObject<LedMC>());
  }
  
  virtual void DoStop() {
    motman->removeMotion(ledID);
    SocketListener::DoStop();
  }

 private: //For Error Suppression
  LEDListener(const LEDListener&);
  LEDListener operator=(const LEDListener&);
  
};

#endif
