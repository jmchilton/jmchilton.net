//-*-c++-*-
#ifndef INCLUDED_PostureListener_h_
#define INCLUDED_PostureListener_h_

#include "Motion/MotionManager.h"
#include "Motion/PostureMC.h"
#include "Motion/MotionSequenceMC.h"
#include "Motion/MotionSequenceEngine.h"
#include "Motion/PostureEngine.h"
#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "IPC/SharedObject.h"

#define MAX_FILE_SIZE 128

//A very naive posture engine listener



class PostureListener : public SocketListener {
 protected:
  //Empty
 public:
  PostureListener() :
    SocketListener("PostureListener", false, sizeof(int)+MAX_FILE_SIZE*sizeof(char))
    {}

  virtual void processData(int size) { //Called when buffer fills    
    int num;
    char *myBuffer = buffer;
    char filename[MAX_FILE_SIZE];
    num = ((int*)myBuffer)[0];
    myBuffer += 4;
    size -= 4;
    for(unsigned int i = 0; i < size; i++)
      {
	filename[i] = myBuffer[i];
      }
    filename[size] = '\0';
    SharedObject< MediumMotionSequenceMC > motion;
    motion->setTime(num);
    motion->setPose( PostureEngine( filename ) );
    motman->addPrunableMotion( motion );
  }
  
  virtual void DoStart() {
    SocketListener::DoStart();
  }
  
  virtual void DoStop() {
    SocketListener::DoStop();
  }

 private: //For Error Suppression
  PostureListener(const PostureListener&);
  PostureListener operator=(const PostureListener&);
  
};

#endif
