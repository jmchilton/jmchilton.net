#ifndef INCLUDED_SocketWriter_h
#define INCLUDED_SocketWriter_h

#include "Wireless/Wireless.h"
#include "AMORAIController.h"

template <class T>
class AMORAIController;

extern std::map<std::string, unsigned int> AMORAI::portMap;

class SocketWriter : public SocketBase {
private:
  unsigned int bufferSize;
  unsigned int bufferPos;
  bool bufferFixed;
  unsigned int comPort;
  Socket * comSocket; 

  //Warning Supression
  SocketWriter(const SocketWriter&);
  SocketWriter& operator=(const SocketWriter&);
  
protected:
  char *buffer;
  
public:
  SocketWriter(std::string classname, bool fixed, int size) :
    SocketBase(classname), 
    bufferSize(size),
    bufferFixed(fixed),
    comPort((AMORAI::portMap[classname])),
    comSocket(NULL),
    buffer(NULL)
    {
      serr->printf("listener port for %s is %d\n", classname.c_str(), comPort);
    }

  int getRawBufferSize() {
    if( bufferFixed ) {
      return bufferSize;
    }
    else {
      return bufferSize + sizeof(int);
    }
  }

  virtual void DoStart() {
    SocketBase::DoStart();
    comSocket=wireless->socket(SocketNS::SOCK_STREAM, 1024, 2048);
    wireless->setDaemon(comSocket);
    wireless->listen(comSocket, comPort);
  }

  virtual void DoStop() {
    wireless->setDaemon(comSocket, false);
    wireless->close(comSocket);
    SocketBase::DoStop();
  }

  bool ready() {
    if((buffer=(char*)comSocket->getWriteBuffer(getRawBufferSize()))) {
      if( !bufferFixed ) { //Pad buffer to writeSize
	  buffer += sizeof(int);
	}
	return true;
      }
    else
      {
	return false;
      }
  }
  
  int send(int writeSize=-1) {
    // send should be preceeded each time ready(), don't fill buffer until ready() has been called
    // Return values, 1 is not send (not connected), 0 if wrote, and
    // -1 if arguement error
    if( bufferFixed  ) {
      comSocket->write(bufferSize);
      return 0;
    }
    else if(writeSize > 0) {
      (((int*)buffer)-1)[0] = writeSize;    
      comSocket->write(sizeof(int)+writeSize);
      return 0;
    }
    else {
      serr->printf("Error Send called with nonpositive size on non fixed buffer!\n");
      return -1;
    }
  }

  //Encodes taken directly from TekkotsuMon's WorldStateSerilizer
  template<class T>
  inline static void encode(char **dst, const T& value) {
    memcpy(*dst, &value, sizeof(T));
    (*dst) += sizeof(T);
  }

  template<class T>
  inline static void encode(char **dst, const T * src, int num) {
    memcpy(*dst, src, num*sizeof(T));
    (*dst) += num*sizeof(T);
  }

  
  ~SocketWriter() {
  }

}; 

#endif
