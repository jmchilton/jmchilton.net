//-*-c++-*-
#ifndef INCLUDED_PersistentMotionListener_h_
#define INCLUDED_PersistentMotionListener_h_
 
#include "Motion/MotionManager.h"
#include "Motion/PostureMC.h"
#include "Shared/RobotInfo.h"
#include "Shared/ERS7Info.h"
#include "SocketListener.h"
#include "IPC/SharedObject.h"

class PersistentMotionListener : public SocketListener {
protected:
  MotionManager::MC_ID poseID;
  PostureMC* pose;
  
public:
  PersistentMotionListener() :
    SocketListener("PersistentMotionListener", false, 2*sizeof(float)),
    poseID(MotionManager::invalid_MC_ID),
    pose(NULL)
  {}
  
  virtual void processData(int size) { //Called when buffer fills    
    serr->printf("PersistentMotionListener sent data with size %d\n", size);
    unsigned int i = 0;
    unsigned int output = 0;
    float val = 0.0; 
    int num = size/4;
    for(i = 0; i < num/2; i+=1)
      {
	output = ((int *)buffer)[i];
	val = ((float *) buffer)[num/2+i];
	if(output < ERS7Info::NumOutputs) {
	  serr->printf("Processing output %d to value %f", output, val);
	  pose->setOutputCmd(output, val);
	} 
	else if (output == ERS7Info::NumOutputs) {
	  serr->printf("Reseting persistent motion listener.");
	  this->resetPoses();
	}
	else {
	  serr->printf("Unknown output: %d\n", output); 
	} 
      }
  }
  
  void resetPoses() {
    motman->removeMotion(poseID);
    poseID=motman->addPersistentMotion(SharedObject<PostureMC>());
    // TODO: Investigate Tekkotsu and determine if there is a memory
    // leek here.
    pose = (PostureMC*) motman->peekMotion(poseID);
  }

  virtual void DoStart() {
    poseID=motman->addPersistentMotion(SharedObject<PostureMC>());
    pose = (PostureMC*)motman->peekMotion(poseID);
    SocketListener::DoStart();
  }
  
  virtual void DoStop() {
    motman->removeMotion(poseID);
    pose = NULL;
    SocketListener::DoStop();
  }
  
private: //For Error Suppression
  PersistentMotionListener(const PersistentMotionListener&);
  PersistentMotionListener operator=(const PersistentMotionListener&);
  
};

#endif
