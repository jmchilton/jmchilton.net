#include "CLASSNAME.h"

//better to put this here instead of the header
using namespace std; 


// [add member function implementations here...]



/*! @file
 * @brief 
 * @author YOURNAMEHERE (Creator)
 *
 * $Author$
 * $Name$
 * $Revision$
 * $State$
 * $Date$
 */
